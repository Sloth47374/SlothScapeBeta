# SlothScape PWA (ready-to-upload)

Files included:
- index.html  (single-file game with inlined JS/CSS)
- manifest.json
- service-worker.js
- offline.html

Quick steps to publish on GitHub Pages (from your phone):
1. Create a new GitHub repo (Public) named e.g. `SlothScape`.
2. Upload the files to the repository root:
   - On mobile browser: Repo -> "Add file" -> "Upload files" and choose each file.
   - If upload of multiple files is awkward, upload them one-by-one using "Create new file" and paste contents.
3. In the repo: go to Settings -> Pages -> Source: choose branch `main` and folder `/ (root)` -> Save.
4. Wait a minute; GitHub will provide the Pages URL: `https://<username>.github.io/<repo>/`.
5. Open that URL in Chrome on your phone. Use the browser menu -> "Add to Home screen" (or the install prompt) to install the PWA.

Notes & troubleshooting:
- If the install prompt doesn't appear, check these:
  - Open `https://<username>.github.io/<repo>/manifest.json` — it must load.
  - Open `https://<username>.github.io/<repo>/service-worker.js` — it must load (SW registers on HTTPS).
- To force updated cache after changes, bump `CACHE_NAME` in `service-worker.js` (e.g., 'slothscape-v2') and re-upload.
- If you prefer custom PNG icons, add /icons/icon-192.png and /icons/icon-512.png files to the repo and update manifest.json.

If you need help uploading files to GitHub Pages from your phone I can walk you through it step-by-step.